import { Menu } from 'antd'
// import { useNavigate } from 'react-router-dom'
// import { TbLayoutDashboard } from 'react-icons/tb'

const MainMenu = ({ active }) => {
  // const navigate = useNavigate()

  return (
    <Menu
      theme='dark'
      mode={'inline'}
      defaultSelectedKeys={[active]}
      style={{
        background: 'var(--sidebar)',
        minHeight: '83vh',
      }}
    >
      {/* <Menu.Item
        key='dashboard'
        className={'sidebar-menu'}
        onClick={() => navigate('/dashboard')}
      >
        Dashboard
      </Menu.Item> */}
      <Menu.Item
        key='services'
        className={'sidebar-menu'}
        // icon={<TbLayoutDashboard className='menu-icon' />}
        // onClick={() => window.href = "/#services"}
      >
        <a href='#services'>Services</a>
      </Menu.Item>
      <Menu.Item
        key='about me'
        className={'sidebar-menu'}
        // icon={<TbLayoutDashboard className='menu-icon' />}
        // onClick={() => navigate('/about me')}
      >
        <a href='#about me'>About me</a>
      </Menu.Item>
      <Menu.Item
        key='portfolio'
        className={'sidebar-menu'}
        // icon={<TbLayoutDashboard className='menu-icon' />}
        // onClick={() => navigate('/portfolio')}
      >
        <a href='#portfolio'>Portfolio</a>
      </Menu.Item>
      <Menu.Item
        key='contact me'
        className={'sidebar-menu'}
        // icon={<TbLayoutDashboard className='menu-icon' />}
        // onClick={() => navigate('/contact me')}
      >
        <a href='#contact me'>Contact me</a>
      </Menu.Item>
    </Menu>
  )
}

export default MainMenu

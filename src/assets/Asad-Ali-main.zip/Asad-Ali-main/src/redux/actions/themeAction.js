export const toggleTheme = () => async (dispatch) => {
  dispatch({
    type: 'TOGGLE_THEME',
  })
}

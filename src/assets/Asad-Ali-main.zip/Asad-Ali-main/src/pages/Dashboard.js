import Header from '../components/Header'
import DesignerComp from '../components/DesignerComp'
import ServicesComp from '../components/ServicesComp'
import AboutMeComp from '../components/AboutMeComp'
import SkillsComp from '../components/SkillsComp'
import PortfolioComp from '../components/PortfolioComp'
import ContactMeComp from '../components/ContactMeComp'
import Footer from '../components/Footer'

const Dashboard = () => {
  return (
    <div>
      <Header />
      <DesignerComp />
      <ServicesComp />
      <AboutMeComp />
      <SkillsComp />
      <PortfolioComp />
      <ContactMeComp />
      <Footer />
    </div>
  )
}

export default Dashboard

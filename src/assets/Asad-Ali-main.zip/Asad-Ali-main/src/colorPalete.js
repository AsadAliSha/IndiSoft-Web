export const colors = [
  '#7B8869',
  '#818F6E',
  '#879673',
  '#8C9D77',
  '#90A37B',
  '#A7B691',
  '#D4DCBD',
  '#DDE3CA',
  '#E4E9D5',
  '#BDC9A7',
]

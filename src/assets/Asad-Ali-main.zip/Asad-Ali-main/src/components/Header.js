import React from 'react'
import { Button } from 'antd'
import Figmalogo from '../assets/Figma-logo.png'
import MenuDrawer from '../layout/MenuDrawer'
const Header = () => {
  return (
    <>
      <div className='header-container container'>
        <div className='width90'>
          <div className='logo-title'>
            <img src={Figmalogo} />
            <div className='header-content'>
              <a href='/#home'> Home</a>

              <a href='#services'>Services</a>

              <a href='/#about me'>About me</a>

              <a href='/#portfolio'>Portfolio</a>

              <a href='/#contact me'>Contact me</a>
            </div>
            <div className='header-button'>
              <Button>
                <span>Hire Me</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className='mobile-menu'>
        <MenuDrawer active={''} />
      </div>
    </>
  )
}

export default Header

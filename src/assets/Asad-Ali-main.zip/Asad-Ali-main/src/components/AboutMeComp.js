import React from 'react'
import { Col, Row, Button } from 'antd'
import Image1 from '../assets/Image-1.png'
import { IoDownloadOutline } from 'react-icons/io5'

// import cv from '../assets/Resume.pdf'

const AboutMeComp = () => {
  const downloadPdf = () => {
    const link = document.createElement('a')
    link.href = require('../assets/Resume.pdf')
    link.download = 'CV'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }
  return (
    <div id='about me' className='aboutme-container'>
      <div className='width90'>
        <div className='aboutme-main-heading'>
          <h1>About Me</h1>
          <p>User Interface and User Experience and Also video editing </p>
        </div>
        <Row gutter={[0, 60]}>
          <Col xl={12} md={24} xs={24}>
            <div className='aboutme-image'>
              <div className='aboutme-background-shade'>
                <img src={Image1} />
              </div>
            </div>
          </Col>
          <Col xl={12} md={24} xs={24}>
            <div className='aboutme-content'>
              <p>
                A software engineer, the modern-day architect of digital realms, navigates the
                ethereal landscapes of code, sculpting intangible structures that shape our
                technological world. With fingers poised over keyboards like virtuoso pianists, they
                compose symphonies of logic, their minds a labyrinth of algorithms and
                solutions.Their canvas is a screen, a vast expanse where lines of code dance in
                intricate patterns, weaving the fabric of programs and applications. Each keystroke
                is a brushstroke, crafting intricate architectures and breathing life into
                innovative designs.In this digital atelier, they don the mantle of problem solvers,
                confronting bugs and glitches like valiant knights in an ever-evolving quest for
                perfection. Debugging becomes a noble pursuit, unraveling the mysteries hidden
                within the tangled webs of code. designs.In this digital atelier.
              </p>
            </div>
            {/* <Col lg={12} md={12} xs={24}> */}
            <div className='aboutme-btn'>
              <div className='aboutme-btn-icon'>
                <Button onClick={downloadPdf}>
                  <IoDownloadOutline />
                  <span>Download CV</span>
                </Button>
              </div>
            </div>
            {/* </Col> */}
          </Col>
        </Row>
      </div>
    </div>
  )
}

export default AboutMeComp

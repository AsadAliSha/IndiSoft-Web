import React from 'react'
import CircularProgressComp from './CircularProgressComp'
import Figma from '../assets/Figma.png'
import Figma2 from '../assets/Figma-2.png'
import Figma3 from '../assets/Figma-3.png'
import Figma4 from '../assets/Figma-4.png'
// import Figma5 from '../assets/Figma-5.png'
import { Col, Row } from 'antd'

const SkillsComp = () => {
  const CircularProgressdata = [
    {
      icon: Figma,
      percentage: '100',
      title: 'Figma',
    },
    {
      icon: Figma2,
      percentage: '100',
      title: 'Adobe XD',
    },
    {
      icon: Figma3,
      percentage: '85',
      title: 'Adobe Photoshop',
    },

    {
      icon: Figma4,
      percentage: '60',
      title: 'Adobe Illustrator',
    },
    // {
    //   icon: Figma5,
    //   percentage: '70',
    //   title: 'Adobe Premiere',
    // },
  ]
  return (
    <div className='skills-container'>
      <div id='portfolio' className='width90'>
        <div className='skills-wrapper'>
          <Row gutter={[30, 30]}>
            {CircularProgressdata?.map((data, i) => (
              <Col lg={6} md={12} xs={24} key={i}>
                <CircularProgressComp
                  icon={data?.icon}
                  title={data?.title}
                  percentage={data?.percentage}
                />
              </Col>
            ))}
          </Row>
        </div>
      </div>
    </div>
  )
}

export default SkillsComp

import React, { useState } from 'react'
import { Button } from 'antd'
import PortfolioScreenShotsComp from '../components/PortfolioScreenShotsComp'

const PortfolioComp = () => {
  const [activeBtn, setActiveBtn] = useState('All')

  const clickHandler = (value) => {
    setActiveBtn(value)
  }

  return (
    <div className='Portfolio-container'>
      <div className='width90 portfolio-main-wrapper'>
        <div className='Portfolio-main-heading'>
          <h1>Portfolio</h1>
        </div>
        <div className='portfolio-btn-container'>
          <div className='portfolio-btn-content' data-aos='flip-left' data-aos-duration='3000'>
            <Button
              className={activeBtn === 'All' ? 'active-btn' : ''}
              onClick={() => clickHandler('All')}
            >
              <span>All</span>
            </Button>
          </div>
          <div className='portfolio-btn-content' data-aos='flip-up' data-aos-duration='3000'>
            <Button
              className={activeBtn === 'Website design' ? 'active-btn' : ''}
              onClick={() => clickHandler('Website design')}
            >
              <span>Website design</span>
            </Button>
          </div>
          <div className='portfolio-btn-content' data-aos='flip-right' data-aos-duration='3000'>
            <Button
              className={activeBtn === 'App Mobile design' ? 'active-btn' : ''}
              onClick={() => clickHandler('App Mobile design')}
            >
              <span>App mobile design</span>
            </Button>
          </div>
          <div className='portfolio-btn-content' data-aos='flip-left' data-aos-duration='3000'>
            <Button
              className={activeBtn === 'App Desktop' ? 'active-btn' : ''}
              onClick={() => clickHandler('App Desktop')}
            >
              <span>App desktop</span>
            </Button>
          </div>
          <div className='portfolio-btn-content' data-aos='flip-up' data-aos-duration='3000'>
            <Button
              className={activeBtn === 'Braiding' ? 'active-btn' : ''}
              onClick={() => clickHandler('Braiding')}
            >
              <span>Braiding</span>
            </Button>
          </div>
        </div>
        <PortfolioScreenShotsComp activeBtn={activeBtn} />
      </div>
    </div>
  )
}

export default PortfolioComp

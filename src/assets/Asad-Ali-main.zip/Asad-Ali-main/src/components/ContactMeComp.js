import React from 'react'
import { Button, Col, Input, Row, Select } from 'antd'

const ContactMeComp = () => {
  const handleChange = (value) => {
    console.log(`selected ${value}`)
  }
  const { TextArea } = Input

  return (
    <div id='contact me' className='contactme-container'>
      <div className='width90'>
        <div className='contactme-main-heading'>
          <h1>Contact me</h1>
          <p>Cultivating Connections: Reach Out and Connect with Me</p>
        </div>
        <Row gutter={[20, 20]}>
          <Col lg={12} xs={24}>
            <Row gutter={[30, 30]}>
              {' '}
              <Col xs={24}>
                {/* <div className='contact-input'> */}
                <Input className='contact-input' placeholder='Name' />
                {/* </div> */}
                {/* </div> */}
              </Col>
              <Col xs={24}>
                <div className=''>
                  <Input placeholder='Phone Number' />
                </div>
              </Col>
              <Col xs={24}>
                <div className=''>
                  <Input placeholder='Timeline' />
                </div>
              </Col>
            </Row>
          </Col>
          <Col lg={12} xs={24}>
            <Row gutter={[30, 30]}>
              <Col xs={24}>
                <div className=''>
                  <Input placeholder='Email' />
                </div>
              </Col>
              <Col xs={24}>
                <div className='select-box'>
                  <>
                    <Select
                      defaultValue='Service of Interest'
                      onChange={handleChange}
                      style={{ width: '100%' }}
                      options={[
                        {
                          value: '',
                          label: '',
                        },
                        {
                          value: '',
                          label: '',
                        },
                        {
                          value: '',
                          // disabled: true,
                          label: '',
                        },
                        {
                          value: '',
                          label: '',
                        },
                      ]}
                    />
                  </>
                </div>
              </Col>
              <Col xs={24}>
                <div className=''>
                  <>
                    {/* <br /> */}
                    <TextArea rows={4} placeholder='Project Details...' maxLength={6} />
                  </>
                </div>
              </Col>
              <Col xs={24}>
                <div className='contactme-btn'>
                  <Button>
                    <span>Send</span>
                  </Button>
                </div>
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    </div>
  )
}

export default ContactMeComp

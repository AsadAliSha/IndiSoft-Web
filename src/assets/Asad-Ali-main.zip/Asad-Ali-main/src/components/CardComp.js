import React from 'react'
import User from '../assets/User.png'

const CardComp = () => {
  return (
    <div className='card-container'>
      <div className='card-image'>
        <img src={User} />
      </div>
      <div className='card-content'>
        <h2>App Design</h2>
        <p>Lorem ipsum dolor sit amet . Imperdiet Lorem ipsum dolor sit amet consectetur</p>
      </div>
    </div>
  )
}

export default CardComp

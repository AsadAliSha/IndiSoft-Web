import React from 'react'
import { Row, Col } from 'antd'
import CardComp from '../components/CardComp'

const ServicesComp = () => {
  return (
    <div id='services' className='service-container container'>
      <div className='width90'>
        <div className='service-main-heading'>
          <h1>Services</h1>
          <p>
            Lorem ipsum dolor sit amet consectetur. Imperdiet convallis blandit felis ligula aliquam
          </p>
        </div>
        <Row gutter={[20, 20]}>
          <Col md={8} sm={12} xs={24}>
            <div className='service-card' data-aos='flip-left' data-aos-duration='2000'>
              <CardComp />
            </div>
          </Col>
          <Col md={8} sm={12} xs={24}>
            <div className='service-card' data-aos='flip-up' data-aos-duration='2000'>
              <CardComp />
            </div>
          </Col>
          <Col md={8} sm={12} xs={24}>
            <div className='service-card' data-aos='flip-right' data-aos-duration='2000'>
              <CardComp />
            </div>
          </Col>
          <Col md={8} sm={12} xs={24}>
            <div className='service-card' data-aos='flip-left' data-aos-duration='2000'>
              <CardComp />
            </div>
          </Col>
          <Col md={8} sm={12} xs={24}>
            <div className='service-card' data-aos='flip-up' data-aos-duration='2000'>
              <CardComp />
            </div>
          </Col>
          <Col md={8} sm={12} xs={24}>
            <div className='service-card' data-aos='flip-right' data-aos-duration='2000'>
              <CardComp />
            </div>
          </Col>
        </Row>
      </div>
    </div>
  )
}

export default ServicesComp

import React from 'react'
import Figmalogo from '../assets/Figma-logo.png'
import { FaInstagram, FaFacebookF, FaWhatsapp, FaTiktok } from 'react-icons/fa'
import { CiLinkedin, CiMail } from 'react-icons/ci'
import { BsTelephone } from 'react-icons/bs'
// import { Col, Row } from 'antd'

const Footer = () => {
  return (
    <div className='footer-container'>
      <div className='width90'>
        <div className='footer-main-logo'>
          <img src={Figmalogo} />
        </div>
        <div className='footer-content'>
          <a href='/#home'>Home</a>
          <a href='/#services'>Services</a>
          <a href='/#about me'>About me</a>
          <a href='/#portfolio'>Portfolio</a>
          <a href='/#contact me'>Contact me</a>
        </div>
        <div className='footer-wrapper'>
          <div className='design-icon'>
            <a href='https://www.facebook.com/asad.shah.702536' className='icon-wrap'>
              <FaFacebookF />
            </a>
            <a href='https://www.instagram.com/asadalishah105/' className='icon-wrap'>
              <FaInstagram />
            </a>
            <a href='https://www.linkedin.com/in/asad-shah-70191b266/' className='icon-wrap'>
              <CiLinkedin />
            </a>
            <a href='https://www.tiktok.com/@asad.shah8384' className='icon-wrap'>
              <FaTiktok />
            </a>
            <a href='"https://wa.me/923452715062"' className='icon-wrap'>
              <FaWhatsapp />
            </a>
          </div>
        </div>
        {/* <Row> */}
        {/* <Col lg={12} md={24} xs={24}> */}
        {/* <div className='footer-wrap'> */}
        <div className='footer-mail'>
          <div className='footer-wrap'>
            <CiMail />
            <a href='mailto:asadalishah105@gamil.com'>asadalishah105@gmail.com</a>
          </div>
          <div className='footer-wrap'>
            <a href='tel:+923452715062'>
              {/* <div className='footer-mail'> */}
              <BsTelephone />
              +92 345 2715 062
              {/* </div> */}
            </a>
          </div>
        </div>
        <div className='footer-cont'>
          <div className='footer-divider'></div>
          <div className='footer-design'>
            <p>Designed by @Asad Ali Shah UI/UX designer</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Footer

import React from 'react'
import { Row, Col, Button } from 'antd'
import Image1 from '../assets/Image-1.png'
// import Image1 from '../assets/Image-1.jpg'
import { FaInstagram, FaFacebookF, FaWhatsapp, FaTiktok } from 'react-icons/fa'
import { CiLinkedin } from 'react-icons/ci'
import CountUp from 'react-countup'
// import cv from '../assets/Resume.pdf'

// import DemoComp from '../components/DemoComp'

const DesignerComp = () => {
  const [exampleText, setExampleText] = React.useState('Asad Ali Shah')

  function rand(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min
  }
  function getRandomLetter() {
    var alphabet = [
      'a',
      'b',
      'c',
      'd',
      'e',
      'f',
      'g',
      'h',
      'i',
      'j',
      '0',
      '1',
      '2',
      '3',
      '4',
      '5',
      '6',
      '7',
      '?',
      '/',
      '{',
      '%',
      '$',
      '#',
      '!',
      '+',
    ]
    return alphabet[rand(0, alphabet.length - 1)]
  }
  function getRandomWord(word) {
    var text = word

    var finalWord = ''
    for (var i = 0; i < text.length; i++) {
      finalWord += text[i] == ' ' ? ' ' : getRandomLetter()
    }

    return finalWord
  }

  // var word = document.querySelector("p");
  var interv = 'undefined'
  var canChange = false
  var globalCount = 0
  var count = 0
  var INITIAL_WORD = exampleText
  var isGoing = false

  function init() {
    if (isGoing) return

    isGoing = true
    var randomWord = getRandomWord(exampleText)
    // word.innerHTML = randomWord;
    setExampleText(randomWord)

    interv = setInterval(function () {
      var finalWord = ''
      for (var x = 0; x < INITIAL_WORD.length; x++) {
        if (x <= count && canChange) {
          finalWord += INITIAL_WORD[x]
        } else {
          finalWord += getRandomLetter()
        }
      }
      setExampleText(finalWord)
      // word.innerHTML = finalWord;
      if (canChange) {
        count++
      }
      if (globalCount >= 20) {
        canChange = true
      }
      if (count >= INITIAL_WORD.length) {
        clearInterval(interv)
        count = 0
        canChange = false
        globalCount = 0
        isGoing = false
      }
      globalCount++
    }, 50)
  }

  React.useEffect(() => {
    setInterval(() => {
      init()
    }, 5000)
  }, [])

  const downloadPdf = () => {
    const link = document.createElement('a')
    link.href = require('../assets/Resume.pdf')
    link.download = 'CV'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className='design-container'>
      <div className='width90'>
        <Row gutter={[0, 20]}>
          <Col lg={12} md={24} xs={24}>
            <div className='design-content'>
              <div className='design-main-heading'>
                <p>Hi I am</p>
                <span>{exampleText}</span>

                <div className='desc'>
                  {/* UI/UX Designer specializing in Shopify & Webflow. */}
                  <span style={{ '--i': '1' }}>U</span>
                  <span style={{ '--i': '2' }}>I</span>
                  <span style={{ '--i': '3' }}>/</span>
                  <span style={{ '--i': '4' }}>U</span>
                  <span style={{ '--i': '5' }}>X</span>
                  {'  '}
                  <span style={{ '--i': '6' }}>d</span>
                  <span style={{ '--i': '7' }}>e</span>
                  <span style={{ '--i': '8' }}>s</span>
                  <span style={{ '--i': '9' }}>i</span>
                  <span style={{ '--i': '10' }}>g</span>
                  <span style={{ '--i': '11' }}>n</span>
                  <span style={{ '--i': '12' }}>e</span>
                  <span style={{ '--i': '13' }}>r</span>
                  {/* Web & Mobile Application Developer */}
                </div>
              </div>
            </div>
            <Col lg={12} md={24} xs={24}>
              <div className='design-icon' data-aos='fade-right' data-aos-duration='2000'>
                <a href='https://www.facebook.com/asad.shah.702536' className='icon-wrap'>
                  <FaFacebookF />
                </a>
                <a href='https://www.instagram.com/asadalishah105/' className='icon-wrap'>
                  <FaInstagram />
                </a>
                <a href='https://www.linkedin.com/in/asad-shah-70191b266/' className='icon-wrap'>
                  <CiLinkedin />
                </a>
                <a href='https://www.tiktok.com/@asad.shah8384' className='icon-wrap'>
                  <FaTiktok />
                </a>
                <a href='https://wa.me/923452715062' className='icon-wrap'>
                  <FaWhatsapp />
                </a>
              </div>
            </Col>
            <Col lg={12} md={24} xs={24}>
              <div className='design-button'>
                <div className='design-btn'>
                  <Button>
                    <span>Hire Me</span>
                  </Button>
                </div>
                <div className='design-btn_1'>
                  <Button onClick={downloadPdf}>
                    <span>Download CV</span>
                  </Button>
                </div>
              </div>
            </Col>
            <Col lg={12} md={24} xs={24}>
              <div className='design-states'>
                <div className='number-states'>
                  {/* <h2>5+</h2> */}
                  <CountUp
                    start={1000}
                    end={5}
                    delay={0}
                    duration={3}
                    suffix='+'
                    onEnd={() => console.log('Ended! 👏')}
                    onStart={() => console.log('Started! 💨')}
                  >
                    {({ countUpRef }) => <h2 ref={countUpRef}></h2>}
                  </CountUp>

                  <span>Experiences</span>
                </div>
                <div className='custom-divider'></div>
                <div className='number-states'>
                  <CountUp
                    start={1000}
                    end={20}
                    delay={0}
                    duration={3}
                    suffix='+'
                    onEnd={() => console.log('Ended! 👏')}
                    onStart={() => console.log('Started! 💨')}
                  >
                    {({ countUpRef }) => <h2 ref={countUpRef}></h2>}
                  </CountUp>
                  {/* <h2>20+</h2> */}
                  <span>Project done</span>
                </div>
                <div className='custom-divider'></div>
                <div className='number-states'>
                  <CountUp
                    start={1000}
                    end={80}
                    delay={0}
                    duration={3}
                    suffix='+'
                    onEnd={() => console.log('Ended! 👏')}
                    onStart={() => console.log('Started! 💨')}
                  >
                    {({ countUpRef }) => <h2 ref={countUpRef}></h2>}
                  </CountUp>
                  {/* <h2>80+</h2> */}
                  <span>Happy Clients</span>
                </div>
                {/* <div className='custom-divider'></div> */}
              </div>
            </Col>
          </Col>
          <Col lg={12} md={24} xs={24}>
            <div className='design-image'>
              <div className='background-shade'>
                <img src={Image1} />
              </div>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  )
}

export default DesignerComp

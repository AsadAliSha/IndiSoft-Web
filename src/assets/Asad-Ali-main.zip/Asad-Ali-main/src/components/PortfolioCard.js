import React from 'react'

const PortfolioCard = ({ projectimage, projectname, category }) => {
  return (
    <div className='portfolio-screenshorts-image' data-aos='flip-left' data-aos-duration='3000'>
      <img src={projectimage} />
      <div className='portfolio-wrapper'>
        <span> {projectname}</span>
        <h2>{category}</h2>
      </div>
    </div>
  )
}

export default PortfolioCard

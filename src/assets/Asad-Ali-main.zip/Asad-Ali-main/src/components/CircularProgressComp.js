// import { Progress } from 'antd'
// import React from 'react'
// import Figma from '../assets/Figma.png'

// const CircularProgressComp = () => {

//   return (
//     <div className='circular-progress-container'>

//       <div className='circular-progress'>
//         <Progress type='circle' percent={100} strokeColor={'#FD6F00'} />
//         <img src={Figma} />
//       </div>
//       <div className='circular-content'>
//       <h2>100%</h2>
//       <p>Figma</p>
//       </div>
//     </div>
//   )
// }

// export default CircularProgressComp

import { Progress } from 'antd'
import React from 'react'
// import Figma from '../assets/Figma.png'

const CircularProgressComp = ({ icon, title, percentage }) => {
  // console.log('CircularProgressdata', CircularProgressdata)

  return (
    <div className='circular-progress-container' data-aos='zoom-in'>
      {/* {CircularProgressdata?.map((item)=>{ */}

      <div className='circular-progress'>
        <Progress type='circle' percent={percentage} strokeColor={'#FD6F00'} />
        <img src={icon} />
      </div>
      <div className='circular-content'>
        <h2>{percentage}%</h2>
        <p>{title}</p>
        {/* <h2>{item?.percentage||'200%'}</h2>
      <p>{item?.title || "fhhfh"}</p> */}
      </div>

      {/* })} */}
    </div>
  )
}

export default CircularProgressComp

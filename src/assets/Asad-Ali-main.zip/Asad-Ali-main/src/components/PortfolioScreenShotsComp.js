import React from 'react'
import { Col, Row } from 'antd'
import Portfolioimage from '../assets/Portfolio-image.png'
import Portfolioimage1 from '../assets/Portfolio-image1.png'
import Portfolioimage2 from '../assets/Portfolio-image2.png'

import PortfolioCard from '../components/PortfolioCard'

const PortfolioData = [
  {
    image: Portfolioimage,
    name: 'Name Project',
    category: 'Website design',
  },
  {
    image: Portfolioimage1,
    name: 'Name Project',
    category: 'App Mobile design',
  },
  {
    image: Portfolioimage2,
    name: 'Name Project',
    category: 'App Desktop',
  },
  {
    image: Portfolioimage1,
    name: 'Name Project',
    category: 'Braiding',
  },
  {
    image: Portfolioimage,
    name: 'Name Project',
    category: 'App Desktop',
  },
  {
    image: Portfolioimage2,
    name: 'Name Project',
    category: 'Braiding',
  },
  {
    image: Portfolioimage,
    name: 'Name Project',
    category: 'Website design',
  },
  {
    image: Portfolioimage2,
    name: 'Name Project',
    category: 'App Mobile design',
  },
  {
    image: Portfolioimage1,
    name: 'Name Project',
    category: 'Braiding',
  },
]

const PortfolioScreenShotsComp = ({ activeBtn }) => {
  return (
    <div className='portfolio-screenshorts'>
      <Row gutter={[30, 30]}>
        {PortfolioData?.filter((_d) =>
          activeBtn === 'All' ? _d : _d?.category === activeBtn,
        )?.map((_d, index) => (
          <Col key={index} lg={8}>
            <PortfolioCard
              projectimage={_d?.image}
              projectname={_d?.name}
              category={_d?.category}
            />
          </Col>
        ))}
      </Row>
    </div>
  )
}

export default PortfolioScreenShotsComp
